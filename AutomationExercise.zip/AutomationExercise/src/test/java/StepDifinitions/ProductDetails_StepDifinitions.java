package StepDifinitions;

import HooksPackage.Hooks;
import Pages.CartPage;
import Pages.HomePage;
import Pages.ProductDeteilsPage;
import Pages.ProductsPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class ProductDetails_StepDifinitions {
    HomePage homePage;
    ProductsPage productsPage;
    ProductDeteilsPage productDeteilsPage;
    CartPage cartPage;

    @Given("I on Products page")
    public void i_on_products_page() {
        homePage = new HomePage(Hooks.driver);
        productsPage = homePage.ClickOnProductsPageLink();
        Assert.assertTrue(productsPage.isAllProductsTitleDisplayed(), "All Products Title is not Displayed");
    }

    @When("I click “View Product” for a product")
    public void iClickViewProductForAProduct() {
        productDeteilsPage = productsPage.ClickOnViewProductsByName("Blue Top");
    }

    @Then("I should be redirected to Product Details Page")
    public void iShouldBeRedirectedToProductDetailsPage() {
        Assert.assertTrue(productDeteilsPage.IsOnProductDetailsPage(),"Done");
    }

    @Given("I am on a product’s detail page")
    public void iAmOnAProductSDetailPage() {
        Assert.assertTrue(productDeteilsPage.IsOnProductDetailsPage(),"Done");

    }

    @When("I fill in “Your Name”, “Email Address”, “Add Review Here!” and submit")
    public void iFillInYourNameEmailAddressAddReviewHereAndSubmit() {
        productDeteilsPage.EnterUrName("Team2");
        productDeteilsPage.EnterUrEmail("team2@gmail.com");
        productDeteilsPage.EnterUrReview("Good Product");
        productDeteilsPage.ClickOnSubmitBtn();
    }

    @Then("the review should be accepted or a confirmation message shown")
    public void theReviewShouldBeAcceptedOrAConfirmationMessageShown() {
        Assert.assertTrue(productDeteilsPage.SuccessMessageDisplayed(),"Done");
    }


    @When("I click on “Add to cart” button and I click View Cart")
    public void iClickOnAddToCartButtonAndIClickViewCart() {
        productDeteilsPage.ClickOnAddToCartBtn();
       cartPage = productDeteilsPage.getViewCartLink();


    }
}

