package StepDifinitions;

import HooksPackage.Hooks;
import Pages.HomePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class Scroll_StepDifi {
    HomePage homePage;

    @Given("I am on any page with content")
    public void I_am_on_any_page_with_content(){
        homePage = new HomePage(Hooks.driver);
        Assert.assertTrue(homePage.isMainTitleDisplayed());

    }


    @When("I scroll down")
    public void iScrollDown() {
        homePage.EnterSubscriptionEmail("team2@gmail.com");
        homePage.ClickOnSubscriptionBtn();

    }

    @And("click the Arrow button")
    public void clickTheArrowButton() {
        homePage.ClickOnScrollUpArrow();
    }

    @Then("the page should scroll to top")
    public void thePageShouldScrollToTop() {
        Assert.assertTrue(homePage.isTitleHomePageDisplayed(),"خلصت ");

    }


    @Then("I should be able to scroll back up manually")
    public void iShouldBeAbleToScrollBackUpManually() {
        homePage =homePage.ClickOnHome();
        Assert.assertTrue(homePage.isTitleHomePageDisplayed(),"خلصت ");

    }
}
