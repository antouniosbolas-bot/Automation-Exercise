package StepDifinitions;

import HooksPackage.Hooks;
import Pages.AccountCreatedPage;
import Pages.FillingDataPage;
import Pages.HomePage;
import Pages.LoginPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class Signup_Login_Step {
    HomePage homePage;
    LoginPage loginPage;
    FillingDataPage fillingDataPage;
    AccountCreatedPage accountCreatedPage;

    @Given("I open Signup and Login page")
    public void I_open_Signup_and_Login_page(){
        homePage = new HomePage(Hooks.driver);
        loginPage=homePage.ClickOnLoginPageLink();
        Assert.assertTrue(loginPage.IsOnLoginPage());

    }

    @When("I fill name, email and password and submit")
    public void iFillNameEmailAndPasswordAndSubmit() {
        loginPage.EnterSignupName("Team2");
        loginPage.EnterSignupEmail("team2@gmail.cooooom");
        fillingDataPage=loginPage.ClickOnSignup();
    }

    @Then("User Should Redirect To FillingData Page")
    public void User_Should_Redirect_To_FillingData_Page() {
        Assert.assertTrue(fillingDataPage.IsOnFillingDataPage());
    }

    @When("I fill correct email and password and submit")
    public void iFillCorrectEmailAndPasswordAndSubmit() {
        loginPage.EnterLoginEmail("team2@gmail.com");
        loginPage.EnterLoginPassword("Team2@123");
        homePage=loginPage.ClickOnLginBtn();
    }

    @Then("User should be redirected to Home Page")
    public void userShouldBeRedirectedToHomePage() {
        Assert.assertTrue(homePage.isMainTitleDisplayed());
    }

    @When("I fill incorrect email or password and submit")
    public void iFillIncorrectEmailOrPasswordAndSubmit() {
        loginPage.EnterLoginEmail("team10@gmail");
        loginPage.EnterLoginPassword("team15");
        homePage=loginPage.ClickOnLginBtn();
    }

    @Then("I should see an error message")
    public void iShouldSeeAnErrorMessage() {
        Assert.assertTrue(loginPage.IsErrorMsgDisplay());

    }


    @Given("I am logged in")
    public void iAmLoggedIn() {
        homePage = new HomePage(Hooks.driver);
        loginPage=homePage.ClickOnLoginPageLink();
        loginPage.EnterLoginEmail("team2@gmail.com");
        loginPage.EnterLoginPassword("Team2@123");
        homePage=loginPage.ClickOnLginBtn();
        Assert.assertTrue(homePage.IsLogidInDisplayd());



    }

    @When("I click Logout")
    public void iClickLogout() {
        loginPage=homePage.ClickOnLogout();
    }

    @Then("I should be logged out and Redirect To Login page")
    public void iShouldBeLoggedOutAndRedirectToLoginPage() {
        Assert.assertTrue(loginPage.IsOnLoginPage());
    }
}
