package StepDifinitions;

import HooksPackage.Hooks;
import Pages.CartPage;
import Pages.CategoryPage;
import Pages.HomePage;
import Pages.ProductsPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class Products_StepDif {
    HomePage homePage;
    ProductsPage productsPage;
    CategoryPage categoryPage;
    CartPage cartPage;

    @Given("the user is on the Products page")
    public void theUserIsOnTheProductsPage() {
        homePage = new HomePage(Hooks.driver);
        productsPage = homePage.ClickOnProductsPageLink();
        Assert.assertTrue(productsPage.isAllProductsTitleDisplayed(), "All Products Title is not Displayed");
    }

    @When("the user enters a product name in the search field")
    public void theUserEntersAProductNameInTheSearchField() {
        productsPage.ClickOnSearch("Blue Top");
        productsPage.ClickOnSearchClickBtn();
    }

    @Then("the search results should be displayed")
    public void theSearchResultsShouldBeDisplayed() {
        Assert.assertEquals(productsPage.getActualSearchResult(), productsPage.getExpectedSearchResult());
    }
    @Given("I am on Products page")
    public void iAmOnProductsPage() {
        homePage = new HomePage(Hooks.driver);
        productsPage = homePage.ClickOnProductsPageLink();
        Assert.assertTrue(productsPage.isAllProductsTitleDisplayed(), "All Products Title is not Displayed");
    }
    @When("I filter products by a Category or Brand")
    public void iFilterProductsByACategoryOrBrand() {
        productsPage.clickCategory("Women");
        categoryPage = productsPage.clickSubCategory("Dress");
        Assert.assertTrue(categoryPage.isTitleDisplayed(), "Ok");
    }
    @Then("I should see only products matching that filter")
    public void iShouldSeeOnlyProductsMatchingThatFilter() {
       Assert.assertTrue(categoryPage.getAllProductsNames().contains("Sleeveless Dress"));
        Assert.assertEquals(categoryPage.getActualTitle(), categoryPage.getExpectedTitle());


    }

    @When("I add a product to cart And I click View Cart")
    public void iAddAProductToCartAndIClickViewCart() throws InterruptedException {
        Thread.sleep(5000);
        productsPage.EnterSubscriptionEmail("team2@gmail.com");
        productsPage.ClickOnSubscriptionBtn();
        productsPage.ClickOnAddToCartByName("Blue Top");
        cartPage = productsPage.getViewCartLink();

    }

    @Then("I should be redirected to Cart Page")
    public void iShouldBeRedirectedToCartPage() {
        Assert.assertTrue(cartPage.isCartPageTitleDisplayed(),"Done");
    }

    @When("I add a product to cart And I click Continue Shopping")
    public void iAddAProductToCartAndIClickContinueShopping() throws InterruptedException {
        productsPage.EnterSubscriptionEmail("team2@gmail.com");
        productsPage.ClickOnSubscriptionBtn();
        productsPage.ClickOnAddToCartByName("Blue Top");

        productsPage.getContinueShoppingBtn();
    }

    @Then("I should stay on Products Page")
    public void iShouldStayOnProductsPage() {
       Assert.assertEquals(productsPage.getActualTitle(), productsPage.getExpectedTitle());

    }
}

