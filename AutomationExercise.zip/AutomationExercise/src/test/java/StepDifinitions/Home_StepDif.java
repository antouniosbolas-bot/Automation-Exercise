package StepDifinitions;

import HooksPackage.Hooks;
import Pages.HomePage;
import Pages.ProductDeteilsPage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.testng.Assert;

public class Home_StepDif {
    HomePage homePage;
    ProductDeteilsPage productDeteilsPage;


    @Given("I Open Home Page")
    public void i_open_home_page() {
        homePage = new HomePage(Hooks.driver);
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Main Title is not Displayed");
    }


    @When("I should see the list of featured products with name and price")
    public void iShouldSeeTheListOfFeaturedProductsWithNameAndPrice() {
        Assert.assertTrue(homePage.getAllProducts().size()>0,"Done");
        homePage.getAllProductsPrices();
        homePage.getAllProductsNames();

    }

    @Then("each product should have a View Product link")
    public void eachProductShouldHaveAViewProductLink() {
        productDeteilsPage=homePage.ClickOnViewProductsByName("Blue Top");

    }

    @When("I enter a valid email in subscription field and submit")
    public void iEnterAValidEmailInSubscriptionFieldAndSubmit() {
        homePage.EnterSubscriptionEmail("test@gmail.com");
        homePage.ClickOnSubscriptionBtn();
    }
    @Then("I should see confirmation that subscription is successful")
    public void iShouldSeeConfirmationThatSubscriptionIsSuccessful() {
        Assert.assertEquals(homePage.getActualSubscriptionSuccessMessage(),homePage.getExpectedSubscriptionSuccessMessage());
    }

}

