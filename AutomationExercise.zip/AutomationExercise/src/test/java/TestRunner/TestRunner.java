package TestRunner;


import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(
        features = "src/main/resources/Features",
glue = {"HooksPackage","StepDifinitions"},
        plugin = {
                "html:target/cucumber_report.html"
        }
)


public class TestRunner extends AbstractTestNGCucumberTests {

}
