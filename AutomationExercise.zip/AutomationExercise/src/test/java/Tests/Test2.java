package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test2 extends BaseTestClass {
@Test
    public void Login_User_with_correct_email_and_password(){
    Assert.assertTrue(homePage.isMainTitleDisplayed());
    loginPage=homePage.ClickOnLoginPageLink();
    Assert.assertEquals(loginPage.getActualLoginText(),loginPage.getExpectedLoginText());
    loginPage.EnterLoginEmail("team2@gmail.co");
    loginPage.EnterLoginPassword("Team2@123");
    homePage=loginPage.ClickOnLginBtn();
    Assert.assertEquals(homePage.getActualUserName(),homePage.getExpectedUserName());
    Assert.assertTrue(homePage.isUserNameDisplayed());

   accountDeletedPage=homePage.ClickOnDeleteAccountBtn();
    Assert.assertTrue(accountDeletedPage.getActualTitle().contains(accountDeletedPage.ExpectedTitle()),"100 100");






}
}

