package Tests;

import BaseTest.BaseTestClass;
import com.beust.ah.A;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test13 extends BaseTestClass {
    @Test
    public void Verify_Product_quantity_in_Cart(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Mpabbe");
        productDeteilsPage=homePage.ClickOnViewProductsByName("Blue Top");
        productDeteilsPage.EnterQuantity("4");
        productDeteilsPage.ClickOnAddToCartBtn();
        cartPage=productDeteilsPage.getViewCartLink();
        Assert.assertFalse(cartPage.CartPageIsntEmpty());
        Assert.assertEquals(cartPage.getQuantity("Blue Top"),4);









        


    }

}
