package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test11 extends BaseTestClass {
    @Test
    public void Verify_Subscription_in_Cart_page(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"RMA");
        cartPage=homePage.ClickOnCartPageLink();
        Assert.assertEquals(cartPage.getActualSubscriptionTitle(),cartPage.getExpectedSubscriptionTitle());
        cartPage.EnterSubscriptionEmail("team2@gmail.co");
        cartPage.ClickOnSubscriptionBtn();
        Assert.assertEquals(cartPage.getActualSubscriptionSuccessMessage(),cartPage.getExpectedSubscriptionSuccessMessage());
    }
}
