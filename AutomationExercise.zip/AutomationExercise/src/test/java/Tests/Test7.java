package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test7 extends BaseTestClass {
    @Test
    public void Verify_Test_Cases_Page(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"محمد و انطونيوس ");
        testCasesPage=homePage.ClickOnTestCases();
        Assert.assertEquals(testCasesPage.getActualTitle(),testCasesPage.getExpectedTitle(),"ivvvv");

    }
}
