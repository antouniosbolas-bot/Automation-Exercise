package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test21 extends BaseTestClass {
    @Test
    public void Add_review_on_product(){
       productsPage= homePage.ClickOnProductsPageLink();
       Assert.assertTrue(productsPage.isAllProductsTitleDisplayed());
       productDeteilsPage=productsPage.ClickOnViewProductsByName("Blue Top");
       Assert.assertTrue(productDeteilsPage.WriteReview(),"is Displayed");
       productDeteilsPage.EnterUrName("Islam");
       productDeteilsPage.EnterUrEmail("islam@gmail.com");
       productDeteilsPage.EnterUrReview("Useless");
       productDeteilsPage.ClickOnSubmitBtn();
       Assert.assertTrue(productDeteilsPage.SuccessMessageDisplayed(),"Success Message is Displayed");
       

    }
}
