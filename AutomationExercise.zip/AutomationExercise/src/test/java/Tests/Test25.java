package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test25 extends BaseTestClass {
    @Test
    public void Verify_Scroll_Up_using_Arrow_button_and_Scroll_Down_functionality(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Big minus");
        Assert.assertTrue(homePage.isSubscriptionTitleDisplayed(),"Big Bounus");
        homePage.EnterSubscriptionEmail("team2@gmail.com");
        homePage.ClickOnSubscriptionBtn();
        homePage.ClickOnScrollUpArrow();
        Assert.assertTrue(homePage.isTitleHomePageDisplayed(),"خلصت ");



    }
}
