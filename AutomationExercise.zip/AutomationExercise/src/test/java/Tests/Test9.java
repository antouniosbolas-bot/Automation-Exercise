package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test9 extends BaseTestClass {
    @Test
    public void Search_Product() {
        Assert.assertTrue(homePage.isMainTitleDisplayed());
        productsPage = homePage.ClickOnProductsPageLink();
        Assert.assertTrue(productsPage.isAllProductsTitleDisplayed());
        productsPage.ClickOnSearch("Blue Top");
        productsPage.ClickOnSearchClickBtn();
        Assert.assertEquals(productsPage.getActualSearchResult(), productsPage.getExpectedSearchResult());
        Assert.assertTrue(productsPage.getAllProductsNames().contains("Blue Top"));



    }
    }

