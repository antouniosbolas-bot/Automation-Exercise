package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;



public class Test5 extends BaseTestClass {
    @Test
    public void Register_User_with_existing_email() {
        Assert.assertTrue(homePage.isMainTitleDisplayed(), "حنا تمام ");
        loginPage = homePage.ClickOnLoginPageLink();
        Assert.assertEquals(loginPage.getActualNewUserText(), loginPage.getExpectedNewUserText(), "Done");
        loginPage.EnterSignupName("Team2");
        loginPage.EnterSignupEmail("team2@gmail.co");
        loginPage.ClickOnSignup();
        Assert.assertEquals(loginPage.getActualExistingEmailErrorText(), loginPage.getExpectedExistingEmailErrorText(), "عااااش ي رجالة ");

    }
}
