package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test3 extends BaseTestClass {
@Test
    public void  Login_User_with_incorrect_email_and_password(){
    Assert.assertTrue(homePage.isMainTitleDisplayed());
    loginPage=homePage.ClickOnLoginPageLink();
    Assert.assertEquals(loginPage.getActualLoginText(),loginPage.getExpectedLoginText());
    loginPage.EnterLoginEmail("team3@gmail.com");
    loginPage.EnterLoginPassword("Team2@1234");
    homePage=loginPage.ClickOnLginBtn();
    Assert.assertEquals(loginPage.getActualLoginErrorText(),loginPage.getExpectedLoginErrorText());
    }
}
