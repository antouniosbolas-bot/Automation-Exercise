package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test4 extends BaseTestClass {
    @Test
    public void Logout_User(){
        Assert.assertTrue(homePage.isMainTitleDisplayed());
        loginPage=homePage.ClickOnLoginPageLink();
        Assert.assertEquals(loginPage.getActualLoginText(),loginPage.getExpectedLoginText());
        loginPage.EnterLoginEmail("team2@gmail.co");
        loginPage.EnterLoginPassword("Team2@123");
        homePage=loginPage.ClickOnLginBtn();
        Assert.assertEquals(homePage.getActualUserName(),homePage.getExpectedUserName());
        Assert.assertTrue(homePage.isUserNameDisplayed());
        loginPage=homePage.ClickOnLogout();

        Assert.assertEquals(loginPage.getActualLoginText(),loginPage.getExpectedLoginText());




    }
}
