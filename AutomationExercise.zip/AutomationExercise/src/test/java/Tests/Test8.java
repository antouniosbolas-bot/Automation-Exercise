package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test8 extends BaseTestClass {
    @Test
    public void Verify_All_Products_and_product_detail_page(){
        Assert.assertTrue(homePage.isMainTitleDisplayed());
        productsPage=homePage.ClickOnProductsPageLink();
        Assert.assertEquals(productsPage.getActualTitle(),productsPage.getExpectedTitle(),"Prins");
        Assert.assertTrue(productsPage.isAllProductsTitleDisplayed());
       productDeteilsPage = productsPage.ClickOnViewProductsByName("Blue Top");

     Assert.assertEquals(productDeteilsPage.getNameOfProduct(),"Blue Top");
        Assert.assertEquals(productDeteilsPage.getCategoryOfProduct(), "Category: Women > Tops");
        Assert.assertEquals(productDeteilsPage.getPriceOfProduct(),"Rs. 500");
        Assert.assertEquals(productDeteilsPage.getConditionOfProduct(), "Condition: New");
        Assert.assertEquals(productDeteilsPage.getBrandOfProduct(), "Brand: Polo");


    }

}
