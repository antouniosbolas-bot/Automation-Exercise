package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class Test23 extends BaseTestClass {
    @Test
    public void Verify_address_details_in_checkout_page() {
        SoftAssert softAssert = new SoftAssert();
        Assert.assertTrue(homePage.isMainTitleDisplayed(), "Islam Have A Task");
        loginPage = homePage.ClickOnLoginPageLink();
        loginPage.EnterSignupName("Team2");
        loginPage.EnterSignupEmail("team2@gmail.coooonmooooom");
        filingDataPage = loginPage.ClickOnSignup();
        filingDataPage.ClickOnMr();
        filingDataPage.EnterPassword("Team2@123");
        filingDataPage.SelectDays(21);
        filingDataPage.SelectMonth(7);
        filingDataPage.SelectYear("2006");
        filingDataPage.ClickOnSign_up_for_our_newsletter();
        filingDataPage.ClickOnReceive_special_offers_from_our_partners();
        filingDataPage.EnterFirstName("Team2");
        filingDataPage.EnterLastName("Team2");
        filingDataPage.EnterCompany("Amit");
        filingDataPage.EnterAdressOne("Cairo");
        filingDataPage.EnterAdressTwo("Ramses");
        filingDataPage.SelectYourCuntry("India");
        filingDataPage.EnterYourState("KafrElShiekh");
        filingDataPage.EnteryourCity("Sila El Gharbia");
        filingDataPage.EnterYourZipCode("10001");
        filingDataPage.EnterYourPhone("01284453186");
        accountCreatedPage = filingDataPage.ClickOnCreateAccount();
        Assert.assertEquals(accountCreatedPage.ActualTitel(), accountCreatedPage.getExpectedTitel());
        homePage = accountCreatedPage.ClickOnContinueBtn();
        Assert.assertTrue(homePage.isUserNameDisplayed());
        homePage.ClickOnAddToCartByName("Blue Top");
        homePage.getContinueShoppingBtn();
        cartPage = homePage.ClickOnCartPageLink();
        Assert.assertTrue(cartPage.isCartPageTitleDisplayed());
        checkOutPage = cartPage.ClickOnCheckOutBtn();
        softAssert.assertTrue(checkOutPage.getDelivaryAddress().contains("Ramses"));
        softAssert.assertTrue(checkOutPage.getBillingAddress().contains("01284453186"));
        accountDeletedPage = checkOutPage.ClickOnDeleteAccountBtn();
        Assert.assertEquals(accountDeletedPage.getActualTitle(), accountDeletedPage.ExpectedTitle(), "100 100");
//        softAssert.assertAll();
    }

}
