package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test6 extends BaseTestClass {
    @Test
    public void Contact_Us_Form(){
        Assert.assertTrue(homePage.isMainTitleDisplayed());
        contactUsPage=homePage.ClickOnContactUs();
        Assert.assertEquals(contactUsPage.getActualGetInTouchText(),contactUsPage.getExpectedGetInTouchText(),"اساااااااطير ");
        contactUsPage.ENterUrName("Team2");
        contactUsPage.EnterUrEmail("team2@gmail.co");
        contactUsPage.EnterSubject("Our Team");
        contactUsPage.EnterMSG("MY name is Team2");
        contactUsPage.ClickOnSubmitBtn();
        contactUsPage.AcceptAlert();
        Assert.assertEquals(contactUsPage.getActualSuccessMSG(),contactUsPage.getExpectedSuccessMSG(),"عليا الطلاق جامدييييين ");
             homePage=contactUsPage.ClickOnHomeBtn();
    }
}
