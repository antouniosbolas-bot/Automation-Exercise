package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test17 extends BaseTestClass {
    @Test
    public void Remove_Products_From_Cart(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Big minus");
        homePage.ClickOnAddToCartByName("Blue Top");
        cartPage=homePage.ClickOnCartPageLink();
        Assert.assertTrue(cartPage.isCartPageTitleDisplayed(),"متشافة و مية مية ");
        cartPage.ClickOnDeleteBtn("Blue Top");
        Assert.assertTrue(cartPage.IsProductDeleted("Blue Top"),"hsshshs");
    }
}
