package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test15 extends BaseTestClass {
    @Test
    public void Place_Order_Register_before_Checkout(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Big minus");
       loginPage=homePage.ClickOnLoginPageLink();
        loginPage.EnterSignupName("Team2");
        loginPage.EnterSignupEmail("team2@gmail.coooooooooooooom");
        filingDataPage=loginPage.ClickOnSignup();
        Assert.assertEquals(filingDataPage.getActualConfirmText(),filingDataPage.getExpectedConfirmText(),"Done");
        filingDataPage.ClickOnMr();
        Assert.assertTrue(filingDataPage.MrIsSelected());
        filingDataPage.EnterPassword("Team2@123");
        filingDataPage.SelectDays(21);
        filingDataPage.SelectMonth(7);
        filingDataPage.SelectYear("2006");
        filingDataPage.ClickOnSign_up_for_our_newsletter();
        filingDataPage.ClickOnReceive_special_offers_from_our_partners();
        filingDataPage.EnterFirstName("Team2");
        filingDataPage.EnterLastName("Team2");
        filingDataPage.EnterCompany("Amit");
        filingDataPage.EnterAdressOne("Cairo");
        filingDataPage.EnterAdressTwo("Ramses");
        filingDataPage.SelectYourCuntry("India");
        filingDataPage.EnterYourState("KafrElShiekh");
        filingDataPage.EnteryourCity("Sila El Gharbia");
        filingDataPage.EnterYourZipCode("10001");
        filingDataPage.EnterYourPhone("01284453186");
        accountCreatedPage=filingDataPage.ClickOnCreateAccount();
        Assert.assertEquals(accountCreatedPage.ActualTitel(),accountCreatedPage.getExpectedTitel());
        homePage=accountCreatedPage.ClickOnContinueBtn();
        Assert.assertEquals(homePage.getActualUserName(),homePage.getExpectedUserName());
        Assert.assertTrue(homePage.isUserNameDisplayed());
        homePage.ClickOnAddToCartByName("Blue Top");
        homePage.getContinueShoppingBtn();
        cartPage=homePage.ClickOnCartPageLink();
        Assert.assertTrue(cartPage.isCartPageTitleDisplayed(),"متشافة و مية مية ");
        checkOutPage=cartPage.ClickOnCheckOutBtn();
        Assert.assertEquals(checkOutPage.getExpectedResultTest(),checkOutPage.getActualResultText());
        checkOutPage.AddComment("product is sooooo good ");
        paymentPage=checkOutPage.ClickOnPlaceOrderBtn();
        paymentPage.SendNameOnCard("We are Team3");
        paymentPage.SendNumberOnCard("012844531861234");
        paymentPage.SendCVC("123");
        paymentPage.SendMonth("12");
        paymentPage.SendYear("2039");
        paymentDonePage=paymentPage.ClickOnConfirmOrder();
        // Assert.assertTrue(paymentPage.isConfirmOrderTextDisplayed());
      accountDeletedPage=paymentDonePage.ClickOnDeleteAccountBtn();
        Assert.assertEquals(accountDeletedPage.getActualTitle(),accountDeletedPage.ExpectedTitle(),"100 100");
        accountDeletedPage.ClickOnContinueBtn();

    }
}

