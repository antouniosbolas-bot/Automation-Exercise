package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test1 extends BaseTestClass {
    @Test
    public void  Verify_that_home_page_is_visible_successfully(){
        Assert.assertTrue(homePage.isMainTitleDisplayed());
        loginPage=homePage.ClickOnLoginPageLink();
        Assert.assertEquals(loginPage.getActualNewUserText(),loginPage.getExpectedNewUserText(),"Done");
        loginPage.EnterSignupName("Team2");
        loginPage.EnterSignupEmail("team2@gmail.com");
       filingDataPage= loginPage.ClickOnSignup();
      Assert.assertEquals(filingDataPage.getActualConfirmText(),filingDataPage.getExpectedConfirmText(),"Done");
      filingDataPage.ClickOnMr();
      Assert.assertTrue(filingDataPage.MrIsSelected());
/*      filingDataPage.EnterName("");
       filingDataPage.EnterEmail("");*/
      filingDataPage.EnterPassword("Team2@123");
      filingDataPage.SelectDays(21);
      filingDataPage.SelectMonth(7);
      filingDataPage.SelectYear("2006");
      filingDataPage.ClickOnSign_up_for_our_newsletter();
      filingDataPage.ClickOnReceive_special_offers_from_our_partners();
      filingDataPage.EnterFirstName("Team2");
      filingDataPage.EnterLastName("Team2");
      filingDataPage.EnterCompany("Amit");
      filingDataPage.EnterAdressOne("Cairo");
      filingDataPage.EnterAdressTwo("Ramses");
      filingDataPage.SelectYourCuntry("India");
      filingDataPage.EnterYourState("KafrElShiekh");
      filingDataPage.EnteryourCity("Sila El Gharbia");
      filingDataPage.EnterYourZipCode("10001");
      filingDataPage.EnterYourPhone("01284453186");
      accountCreatedPage=filingDataPage.ClickOnCreateAccount();
      Assert.assertEquals(accountCreatedPage.ActualTitel(),accountCreatedPage.getExpectedTitel());
      homePage=accountCreatedPage.ClickOnContinueBtn();
        Assert.assertEquals(homePage.getActualUserName(),homePage.getExpectedUserName());
        Assert.assertTrue(homePage.isUserNameDisplayed());


      accountDeletedPage=homePage.ClickOnDeleteAccountBtn();
      Assert.assertTrue(accountDeletedPage.getActualTitle().contains(accountDeletedPage.ExpectedTitle()),"100 100");


        }
    }

