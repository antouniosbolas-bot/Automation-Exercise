package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test20 extends BaseTestClass {
    @Test
    public void Search_Products_and_Verify_Cart_After_Login(){
        productsPage = homePage.ClickOnProductsPageLink();
        Assert.assertTrue(productsPage.isAllProductsTitleDisplayed());
        productsPage.ClickOnSearch("Blue Top");
        productsPage.ClickOnSearchClickBtn();
        Assert.assertEquals(productsPage.getActualSearchResult(),productsPage.getExpectedSearchResult());
        productsPage.ClickOnAddToCartByName("Blue Top");
        cartPage = productsPage.getViewCartLink();
        Assert.assertTrue(cartPage.isCartPageTitleDisplayed(),"متشافة و مية مية ");
        cartPage.ClickOnCheckOutBtn();
       loginPage = cartPage.ClickOnLoginLink();
       loginPage.EnterLoginEmail("team2@gmail.com");
       loginPage.EnterLoginPassword("Team2@123");
       homePage = loginPage.ClickOnLginBtn();
       cartPage = homePage.ClickOnCartPageLink();
        Assert.assertTrue(cartPage.isCartPageTitleDisplayed(),"متشافة  ");


    }
}