package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test26 extends BaseTestClass {
    @Test
    public void Verify_Scroll_Up_without_Arrow_button_and_Scroll_Down_functionality(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Big minus");
        Assert.assertTrue(homePage.isSubscriptionTitleDisplayed(),"Big Bounus");
        homePage.EnterSubscriptionEmail("team2@gmail.com");
        homePage.ClickOnSubscriptionBtn();
        homePage =homePage.ClickOnHome();
        Assert.assertTrue(homePage.isTitleHomePageDisplayed(),"خلصت ");
    }

}
