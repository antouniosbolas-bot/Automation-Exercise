package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test12 extends BaseTestClass {
    @Test
    public void Add_Products_in_Cart(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"CR7");
        productsPage=homePage.ClickOnProductsPageLink();
        productsPage.ClickOnAddToCartByName("Blue Top");
        productsPage.getContinueShoppingBtn();
        productsPage.ClickOnAddToCartByName("Men Tshirt");
        cartPage=productsPage.getViewCartLink();
        Assert.assertEquals(cartPage.getCartItemsNum(),2);
        Assert.assertEquals(cartPage.getPrice("Blue Top"),"Rs. 500");
        Assert.assertEquals(cartPage.getPrice("Men Tshirt"),"Rs. 400");
        Assert.assertEquals(cartPage.getQuantity("Blue Top"),1);
        Assert.assertEquals(cartPage.getQuantity("Men Tshirt"),1);
        Assert.assertEquals(cartPage.getTotalPrice("Blue Top"),"Rs. 500");
        Assert.assertEquals(cartPage.getTotalPrice("Men Tshirt"),"Rs. 400");





        
    }
}
