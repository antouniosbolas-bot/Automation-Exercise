package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test24 extends BaseTestClass {
    @Test
    public void Download_Invoice_after_purchase_order()throws InterruptedException{
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Big minus");
        homePage.ClickOnAddToCartByName("Blue Top");
        homePage.getContinueShoppingBtn();
        cartPage=homePage.ClickOnCartPageLink();
        Assert.assertTrue(cartPage.isCartPageTitleDisplayed()," تمام ");
        cartPage.ClickOnCheckOutBtn();
        loginPage=cartPage.ClickOnLoginLink();
        loginPage.EnterSignupName("Team2");
        loginPage.EnterSignupEmail("team2@gmail.coomoomoooooooo");
        filingDataPage=loginPage.ClickOnSignup();
        Assert.assertEquals(filingDataPage.getActualConfirmText(),filingDataPage.getExpectedConfirmText(),"Done");
        filingDataPage.ClickOnMr();
        Assert.assertTrue(filingDataPage.MrIsSelected());
        filingDataPage.EnterPassword("Team2@123");
        filingDataPage.SelectDays(21);
        filingDataPage.SelectMonth(7);
        filingDataPage.SelectYear("2006");
        filingDataPage.ClickOnSign_up_for_our_newsletter();
        filingDataPage.ClickOnReceive_special_offers_from_our_partners();
        filingDataPage.EnterFirstName("Team2");
        filingDataPage.EnterLastName("Team2");
        filingDataPage.EnterCompany("Amit");
        filingDataPage.EnterAdressOne("Cairo");
        filingDataPage.EnterAdressTwo("Ramses");
        filingDataPage.SelectYourCuntry("India");
        filingDataPage.EnterYourState("KafrElShiekh");
        filingDataPage.EnteryourCity("Sila El Gharbia");
        filingDataPage.EnterYourZipCode("10001");
        filingDataPage.EnterYourPhone("01284453186");
        accountCreatedPage=filingDataPage.ClickOnCreateAccount();
        Assert.assertEquals(accountCreatedPage.ActualTitel(),accountCreatedPage.getExpectedTitel());
        homePage=accountCreatedPage.ClickOnContinueBtn();
        Assert.assertEquals(homePage.getActualUserName(),homePage.getExpectedUserName());
        Assert.assertTrue(homePage.isUserNameDisplayed());
        cartPage=homePage.ClickOnCartPageLink();
        checkOutPage=cartPage.ClickOnCheckOutBtn();
        Assert.assertEquals(checkOutPage.getExpectedResultTest(),checkOutPage.getActualResultText());
        checkOutPage.AddComment("product is sooooo good ");
        paymentPage=checkOutPage.ClickOnPlaceOrderBtn();
        paymentPage.SendNameOnCard("We are Team2");
        paymentPage.SendNumberOnCard("012844531861234");
        paymentPage.SendCVC("123");
        paymentPage.SendMonth("12");
        paymentPage.SendYear("2039");
        paymentDonePage=paymentPage.ClickOnConfirmOrder();
        paymentDonePage.ClickOnDownloadBtn();
        paymentDonePage.ClickOnContinueBtn();
        accountDeletedPage=paymentDonePage.ClickOnDeleteAccountBtn();
        Assert.assertEquals(accountDeletedPage.getActualTitle(),accountDeletedPage.ExpectedTitle(),"100 100");
        accountDeletedPage.ClickOnContinueBtn();

    }
}
