package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test22 extends BaseTestClass {
    @Test
    public void Add_to_cart_from_Recommended_items(){
        Assert.assertTrue(homePage.isRecommendedItemsDisplayed());
        homePage.ClickOnAddToCartByName("Stylish Dress");
       cartPage =homePage.getViewCartLink();
       Assert.assertTrue(cartPage.isCartPageTitleDisplayed());

    }
}
