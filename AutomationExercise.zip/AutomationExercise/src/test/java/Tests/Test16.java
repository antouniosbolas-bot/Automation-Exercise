package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test16 extends BaseTestClass {
    @Test
    public void Place_Order_Login_before_Checkout(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"Big minus");
                loginPage=homePage.ClickOnLoginPageLink();
                loginPage.EnterLoginEmail("team2@gmail.coooooooooooooom");
                loginPage.EnterLoginPassword("Team2@123");
                homePage=loginPage.ClickOnLginBtn();
                Assert.assertEquals(homePage.getActualUserName(),homePage.getExpectedUserName());
                Assert.assertTrue(homePage.isUserNameDisplayed());
                homePage.ClickOnAddToCartByName("Blue Top");
                homePage.getContinueShoppingBtn();
                cartPage=homePage.ClickOnCartPageLink();
                Assert.assertTrue(cartPage.isCartPageTitleDisplayed(),"متشافة و مية مية ");
                checkOutPage=cartPage.ClickOnCheckOutBtn();
                Assert.assertEquals(checkOutPage.getExpectedResultTest(),checkOutPage.getActualResultText());
                checkOutPage.AddComment("product is sooooo good ");
                paymentPage=checkOutPage.ClickOnPlaceOrderBtn();
                paymentPage.SendNameOnCard("We are Team3");
                paymentPage.SendNumberOnCard("012844531861234");
                paymentPage.SendCVC("123");
                paymentPage.SendMonth("12");
                paymentPage.SendYear("2039");
                paymentDonePage=paymentPage.ClickOnConfirmOrder();
                // Assert.assertTrue(paymentPage.isConfirmOrderTextDisplayed());
                accountDeletedPage=paymentDonePage.ClickOnDeleteAccountBtn();
                Assert.assertEquals(accountDeletedPage.getActualTitle(),accountDeletedPage.ExpectedTitle(),"100 100");
                accountDeletedPage.ClickOnContinueBtn();

            }
        }


