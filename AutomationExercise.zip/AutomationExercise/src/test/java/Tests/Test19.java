package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test19 extends BaseTestClass {
    @Test
    public void View_Cart_Brand_Products() {
        productsPage = homePage.ClickOnProductsPageLink();
//        Assert.assertTrue(productsPage.isBrandsSideDisplayed());
        brandsPage = productsPage.clickBrand("Allen Solly Junior");
        Assert.assertTrue(brandsPage.getActualBrandTitle().contains("BRAND - ALLEN SOLLY JUNIOR PRODUCTS"));
        Assert.assertTrue(brandsPage.isBrandTitleDisplayed());

    }

}
