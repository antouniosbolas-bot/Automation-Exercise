package Tests;

import BaseTest.BaseTestClass;
import com.beust.ah.A;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import java.util.List;

public class Test18 extends BaseTestClass {
    @Test
    public void  View_Category_Products(){
       SoftAssert softAssert = new SoftAssert();
        Assert.assertTrue(homePage.isCategorySideDisplayed(),"CR7");
        homePage.clickCategory("Women");
        categoryPage = homePage.clickSubCategory("Dress");

        softAssert.assertTrue(categoryPage.isTitleDisplayed(),"CR8");
        softAssert.assertEquals(categoryPage.getActualTitle(),categoryPage.getExpectedTitle(),"CR9");
        categoryPage.clickCategory("Men");
        categoryPage.clickSubCategory("Tshirts");
//        Assert.assertEquals(categoryPage.getTitle2(),categoryPage.getExpectedTitle2(),"CR11");


    }
}
