package Tests;

import BaseTest.BaseTestClass;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test10 extends BaseTestClass {
    @Test
    public void Verify_Subscriptio_in_home_page(){
        Assert.assertTrue(homePage.isMainTitleDisplayed(),"CR7");
        Assert.assertEquals(homePage.getActualSubscriptionTitle(),homePage.getExpectedSubscriptionTitle());
        homePage.EnterSubscriptionEmail("team2@gmail.co");
        homePage.ClickOnSubscriptionBtn();
        Assert.assertEquals(homePage.getActualSubscriptionSuccessMessage(),homePage.getExpectedSubscriptionSuccessMessage());





    }
}
